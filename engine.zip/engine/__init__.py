"""SIMCO Engine — thermodynamic and mass-transfer calculation core."""

__version__ = "0.1.0"
