"""Route handlers for the SIMCO engine API."""
