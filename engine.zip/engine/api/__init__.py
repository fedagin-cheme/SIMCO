"""API route handlers for IPC bridge."""
