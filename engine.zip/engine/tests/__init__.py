"""SIMCO engine test suite."""
